
% (1) Make sure YALMIP is installed, and appropriately added to the path
% (2) Execute this script
% (3) To install PESTO permanently (for future sessions), make sure to save 
%     the added paths using matlab function 'savepath'
curr=pwd;
addpath(genpath(pwd));
