function cons=StronglyConvexBoundedGradient(pt1,pt2,mu,D,R)
%
% This routine implements the interpolation conditions for strongly convex
% functions with bounded subgradients. Three parameters may be provided: 
%       - a bound D on the maximum distance between any two subgradients 
%       (diameter-type bound: ||g_1-g_2||<= D for any g_1,g_2 being
%       subgradients of the function at (respectively) some x_1 and x_2)
%       (D is nonnegative, possibly infinite).
%       - a bound R on the maximum norm of any subgradient
%       (radius-type bound: ||g||<= R for any g being a
%       subgradient of the function at some x) (R is nonnegative, 
%       possibly infinite),
%       - strong convexity constant mu (mu is nonnegative).
%
% Note: not defining the value of D and/or R automatically corresponds 
%       to set D and/or R to infinity.
%
% To generate a smooth convex function 'f' with diameter-type bound
% D=infinite, radius-type bound R=1 and a strong convexity constant mu=1.5,
% from an instance of PEP called P:
%  >> P=pep();
%  >> param.D=Inf; param.R=1; param.mu=1.5;
%  >> f=P.AddObjective('StronglyConvexBoundedGradient',param);
    if ~(pt1.x.isEqual(pt2.x) && pt1.g.isEqual(pt2.g) && pt1.f.isEqual(pt2.f))
        cons=((pt1.f-pt2.f+pt1.g*(pt2.x-pt1.x)+mu/2*(pt1.x-pt2.x)^2)<=0);
        if D~=Inf
            cons=cons+((pt1.g-pt2.g)^2-D^2<=0);
        end
    else
        if R~=Inf
            cons=((pt1.g)^2-R^2<=0);
        else
            cons=[];
        end
    end
end